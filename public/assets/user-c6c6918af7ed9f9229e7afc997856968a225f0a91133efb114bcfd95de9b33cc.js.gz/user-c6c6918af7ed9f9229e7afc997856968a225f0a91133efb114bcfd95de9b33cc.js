

function changeColor(){
  var body = document.getElementsByTagName("body");

  return;
}
;
